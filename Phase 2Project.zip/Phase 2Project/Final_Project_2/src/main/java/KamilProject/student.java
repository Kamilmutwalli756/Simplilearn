package KamilProject;

public class student {
	private String studid;
	private String studfname;
	private String studlname;
	private String studdob;
	private String studadd;
	private String studphone;
	private String assigncls;
	private String classid;
	

	public String getClassid() {
		return classid;
	}
	public void setClassid(String classid) {
		this.classid = classid;
	}
	public String getAssigncls() {
		return assigncls;
	}
	public void setAssigncls(String assigncls) {
		this.assigncls = assigncls;
	}
	public String getStudid() {
		return studid;
	}
	public void setStudid(String studid) {
		this.studid = studid;
	}
	public String getStudfname() {
		return studfname;
	}
	public void setStudfname(String studfname) {
		this.studfname = studfname;
	}
	public String getStudlname() {
		return studlname;
	}
	public void setStudlname(String studlname) {
		this.studlname = studlname;
	}
	public String getStuddob() {
		return studdob;
	}
	public void setStuddob(String studdob) {
		this.studdob = studdob;
	}
	public String getStudadd() {
		return studadd;
	}
	public void setStudadd(String studadd) {
		this.studadd = studadd;
	}
	public String getStudphone() {
		return studphone;
	}
	public void setStudphone(String studphone) {
		this.studphone = studphone;
	}
	
	
}

