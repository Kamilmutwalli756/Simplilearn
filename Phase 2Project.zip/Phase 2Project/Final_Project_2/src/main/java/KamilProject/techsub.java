package KamilProject;

public class techsub {
	private String techid;
	private String ssubject;
	private String assigntech;
	private String assignclass;
	private String classid;
	
	public String getClassid() {
		return classid;
	}
	public void setClassid(String classid) {
		this.classid = classid;
	}
	public String getAssignclass() {
		return assignclass;
	}
	public void setAssignclass(String assignclass) {
		this.assignclass = assignclass;
	}
	public String getTechid() {
		return techid;
	}
	public void setTechid(String techid) {
		this.techid = techid;
	}
	public String getSsubject() {
		return ssubject;
	}
	public void setSsubject(String ssubject) {
		this.ssubject = ssubject;
	}
	public String getAssigntech() {
		return assigntech;
	}
	public void setAssigntech(String assigntech) {
		this.assigntech = assigntech;
	}
	
	
}
